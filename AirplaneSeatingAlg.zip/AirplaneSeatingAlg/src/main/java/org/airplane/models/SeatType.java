package org.airplane.models;

public enum SeatType {
    AISLE,
    WINDOW,
    CENTER
}
